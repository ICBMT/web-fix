// All media is imported from /uploads (project root) and inlined into the
// single-file build by vite-plugin-singlefile — nothing can go missing.
import { GLB_DATA_URL } from "./glbData";

import whiteLogo from "../media/White.svg?inline";
import blackLogo from "../media/Black.svg?inline";

import mooseheadImg from "../media/work/moosehead.jpg?inline";
import mooseheadVid from "../media/work/moosehead.mp4?inline";
import cobImg from "../media/work/cob.jpg?inline";
import cobVid from "../media/work/cob.mp4?inline";
import difcImg from "../media/work/difc.jpg?inline";
import margielaImg from "../media/work/margiela.jpg?inline";
import renaultImg from "../media/work/renault.jpg?inline";
import omnicellImg from "../media/work/omnicell.jpg?inline";
import gsoftImg from "../media/work/gsoft.jpg?inline";
import ubisoftImg from "../media/work/ubisoft.jpg?inline";
import ventrilocImg from "../media/work/ventriloc.jpg?inline";
import tasmimImg from "../media/work/tasmim.jpg?inline";
import amourliquideImg from "../media/work/amourliquide.jpg?inline";
import sopraImg from "../media/work/sopra.jpg?inline";
import basehabitationImg from "../media/work/basehabitation.jpg?inline";
import caisseImg from "../media/work/caisse.jpg?inline";
import jinnsImg from "../media/work/jinns.jpg?inline";
import biothermImg from "../media/work/biotherm.jpg?inline";

import labAiCore from "../media/lab/ai-core.jpg?inline";
import labAiOrb from "../media/lab/ai-orb.jpg?inline";
import labUiGlass from "../media/lab/ui-glass.jpg?inline";
import labTerminal from "../media/lab/terminal.jpg?inline";
import labWave from "../media/lab/webgl-wave.jpg?inline";
import labSculpt from "../media/lab/sculpt.jpg?inline";
import labMobile from "../media/lab/mobile-app.jpg?inline";
import labDesign from "../media/lab/design-system.jpg?inline";

export const GLB_URL = GLB_DATA_URL;
export const LOGO_WHITE = whiteLogo;
export const LOGO_BLACK = blackLogo;

export const MEDIA: Record<string, { img: string; video?: string }> = {
  moosehead: { img: mooseheadImg, video: mooseheadVid },
  cob: { img: cobImg, video: cobVid },
  difc: { img: difcImg },
  margiela: { img: margielaImg },
  renault: { img: renaultImg },
  omnicell: { img: omnicellImg },
  gsoft: { img: gsoftImg },
  ubisoft: { img: ubisoftImg },
  ventriloc: { img: ventrilocImg },
  tasmim: { img: tasmimImg },
  amourliquide: { img: amourliquideImg },
  sopra: { img: sopraImg },
  basehabitation: { img: basehabitationImg },
  caisse: { img: caisseImg },
  jinns: { img: jinnsImg },
  biotherm: { img: biothermImg },
};

/** AI / product-design R&D visuals (generated for GreePixel) */
export const LAB: Record<string, { img: string; title: string; tag: string }> = {
  "ai-core": { img: labAiCore, title: "Neural Cores", tag: "AGENT PIPELINES" },
  "ai-orb": { img: labAiOrb, title: "Intelligence Fields", tag: "RAG SYSTEMS" },
  "ui-glass": { img: labUiGlass, title: "Glass Dashboards", tag: "PRODUCT UI" },
  terminal: { img: labTerminal, title: "Holo Terminal", tag: "CODE AUDITS" },
  "webgl-wave": { img: labWave, title: "Shader Fields", tag: "GLSL R&D" },
  sculpt: { img: labSculpt, title: "Form Studies", tag: "3D CRAFT" },
  "mobile-app": { img: labMobile, title: "Mobile Systems", tag: "FLUTTER / RN" },
  "design-system": { img: labDesign, title: "Component Atoms", tag: "DESIGN SYSTEMS" },
};

/** Service row hover previews — one visual per capability */
export const SERVICE_PREVIEWS: Record<string, string> = {
  "01": labAiCore,
  "02": labWave,
  "03": labDesign,
  "04": labTerminal,
  "05": labMobile,
  "06": labUiGlass,
  "07": labAiOrb,
  "08": labSculpt,
};
