import "@fontsource/archivo/400.css";
import "@fontsource/archivo/500.css";
import "@fontsource/archivo/600.css";
import "@fontsource/archivo/700.css";
import "@fontsource/archivo/800.css";
import "@fontsource/archivo/900.css";
import "./globals.css";

export const metadata = {
  title: "GreeLogix — AI Software & MVPs That Actually Ship",
  description: "Senior software agency building AI products, custom web & mobile apps and investor-ready MVPs in 4–8 weeks. 150+ products shipped for US, UK, UAE, AU & CA.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="noise"><a href="#main" className="skip-link">Skip to content</a>{children}</body>
    </html>
  );
}
